import React from 'react';

const Page = () => {
    return (
        <div>Página Sobre</div>
    );
}

export default Page;